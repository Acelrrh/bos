#
cd /usr/bin
